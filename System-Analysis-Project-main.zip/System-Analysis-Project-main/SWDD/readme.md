This folder is designed to hold our SWDD for our project
