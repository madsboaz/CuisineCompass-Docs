This is going to be all the diagrams for class
