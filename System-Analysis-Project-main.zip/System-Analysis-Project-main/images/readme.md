Images used for project adn wiki- No diagrams
